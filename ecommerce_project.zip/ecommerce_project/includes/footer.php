</div>
<footer class="bg-dark text-white text-center py-3 mt-5">
    <p>&copy; 2026 E-Shop. All rights reserved.</p>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="/assets/js/main.js"></script>
</body>
</html>
